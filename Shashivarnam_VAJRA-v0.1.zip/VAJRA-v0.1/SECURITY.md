# Security policy

- Keep this prototype bound to `127.0.0.1` for local use.
- Do not expose the API or local model endpoint publicly without authentication, rate limiting, TLS, logging controls and a security review.
- Never commit secrets or private user data.
- Treat retrieved documents as untrusted input. Do not let document text execute tools or override system policy.
- Report security issues privately to the project maintainers before public disclosure.
