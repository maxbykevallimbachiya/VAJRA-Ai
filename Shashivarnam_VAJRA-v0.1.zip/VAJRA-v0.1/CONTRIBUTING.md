# Contributing to Shashivarnam’s VAJRA model

Thanks for helping improve an open, careful Indian-language AI model initiative.

## Before contributing

- Read `docs/DATA_GOVERNANCE.md`.
- Never submit private conversations, personal data, or material without redistribution rights.
- Include source and licence metadata for every contributed dataset record.
- Native-language review is especially valuable. Mark a record `reviewed` only when a human has actually checked it.
- Do not add credentials, API keys, model weights or private datasets to Git.

## Development

1. Create a branch.
2. Install with `python -m pip install -e ".[dev]"`.
3. Add or update tests.
4. Run `python -m pytest`.
5. Describe what changed and how you tested it.

## Dataset pull requests

Include provenance, licence evidence, intended use, language, collection date where relevant, privacy review and known limitations. Maintainers may reject data whose rights or provenance are unclear.
