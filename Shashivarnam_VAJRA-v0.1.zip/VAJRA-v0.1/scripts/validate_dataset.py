from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from vajra.dataset.validator import validate_jsonl, DatasetValidationError  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate VAJRA Indic JSONL data and provenance fields.")
    parser.add_argument("path", help="Path to a JSONL dataset")
    parser.add_argument("--require-reviewed", action="store_true", help="Require human-reviewed examples and reviewer names")
    args = parser.parse_args()
    try:
        summary = validate_jsonl(args.path, require_reviewed=args.require_reviewed)
    except (DatasetValidationError, FileNotFoundError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
