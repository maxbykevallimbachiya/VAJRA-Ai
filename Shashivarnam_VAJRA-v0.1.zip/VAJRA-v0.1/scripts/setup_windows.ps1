$ErrorActionPreference = "Stop"

Write-Host "VAJRA v0.1 setup" -ForegroundColor Cyan
Write-Host "This installs only the local API and tests. It does not download an AI model."

$pythonLauncher = Get-Command py -ErrorAction SilentlyContinue
if (-not $pythonLauncher) {
    throw "Python Launcher 'py' was not found. Install Python 3.11 from https://www.python.org/downloads/ and enable the launcher."
}

py -3.11 --version
if ($LASTEXITCODE -ne 0) {
    throw "Python 3.11 was not found. Install Python 3.11, then run this script again."
}

if (-not (Test-Path ".venv")) {
    py -3.11 -m venv .venv
}

$venvPython = Join-Path (Get-Location) ".venv\Scripts\python.exe"
& $venvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "Could not upgrade pip." }
& $venvPython -m pip install -e ".[dev]"
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed. Check your internet connection and Python version." }
& $venvPython -m pytest -q
if ($LASTEXITCODE -ne 0) { throw "Tests failed. Read the test output above." }
& $venvPython scripts\validate_dataset.py data\samples\seed_examples.jsonl
if ($LASTEXITCODE -ne 0) { throw "Sample dataset validation failed." }

Write-Host "Setup complete. Start the API with:" -ForegroundColor Green
Write-Host ".\.venv\Scripts\uvicorn.exe vajra.api.main:app --host 127.0.0.1 --port 8000 --reload"
