$ErrorActionPreference = "Stop"
$uvicorn = Join-Path (Get-Location) ".venv\Scripts\uvicorn.exe"
if (-not (Test-Path $uvicorn)) {
    throw "VAJRA is not installed yet. Run: .\scripts\setup_windows.ps1"
}
& $uvicorn vajra.api.main:app --host 127.0.0.1 --port 8000 --reload
