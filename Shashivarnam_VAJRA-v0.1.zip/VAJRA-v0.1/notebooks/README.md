# Notebooks

- `00_qwen3_0_6b_baseline.ipynb`: inference-only baseline for Kaggle/Colab. Uses the original Qwen3-0.6B weights; it does not train or fine-tune.

Upload the notebook to Kaggle or Colab. Select GPU if a free one is available and enable Internet to download the model. Free allocations and quotas vary.
