# Shashivarnam | VAJRA v0.1 — Indian-language AI model starter

**Shashivarnam is the company / initiative; VAJRA is its flagship Indian-language AI model under development.** This repository is the small, reproducible research starter for VAJRA. This repository is designed for a Windows PC with 12 GB RAM and integrated graphics. The local application uses CPU-friendly retrieval; the Qwen3-0.6B model baseline runs in a separate Kaggle/Colab notebook when a free GPU is available.

> **Honest scope:** v0.1 is a working RAG prototype, a dataset-validation pipeline, and a model-evaluation notebook. It is not a newly trained foundation model or AGI. The Qwen notebook measures the unmodified Qwen3-0.6B baseline; it does not fine-tune it.

## What is included

- FastAPI local API with `/health`, `/documents`, and `/ask` endpoints.
- CPU-friendly multilingual retrieval using character n-gram TF-IDF (no embedding model download required).
- Evidence snippets and source metadata in every retrieval result.
- Optional connection to a **locally hosted** OpenAI-compatible model server. No paid API is configured or required.
- JSONL Indic dataset schema, original demonstration examples, validation script and licence/provenance fields.
- `notebooks/00_qwen3_0_6b_baseline.ipynb` for Kaggle or Colab.
- Automated tests.

## Company and model identity

- **Company / initiative:** Shashivarnam
- **Flagship model:** VAJRA
- **Initial research focus:** Gujarati, Hindi and English
- **Product direction:** VAJRA EDU, an education product powered by the VAJRA model

The name identifies the founder-selected brand; it does not by itself imply that a legal entity has been incorporated or a trademark registered. Check availability and complete the appropriate legal steps before formal commercial use.

## 1. Requirements

- Windows 10/11, macOS or Linux.
- Python **3.10–3.13** recommended.
- Git (optional but recommended).
- 1–2 GB free disk space for the app and dependencies; more if you download model files.
- Internet for installing Python packages and (in the cloud notebook) downloading Qwen3.

**Do not download Qwen3 onto your 12 GB PC just to follow this starter.** Run the notebook on Kaggle/Colab first. The local API works without loading a language model.

## 2. Install on Windows (PowerShell)

Open PowerShell in the `VAJRA-v0.1` folder. For the guided setup script, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\setup_windows.ps1
```

Or install manually:

```powershell
py -3.11 --version
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

If PowerShell blocks activation, run this **for the current terminal only**:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Then test the installation:

```powershell
python -m pytest
python scripts\validate_dataset.py data\samples\seed_examples.jsonl
```

### macOS / Linux

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
python -m pytest
python scripts/validate_dataset.py data/samples/seed_examples.jsonl
```

## 3. Run the Shashivarnam research API locally (no GPU, no model download)

From the repository root with the virtual environment activated:

```powershell
uvicorn vajra.api.main:app --host 127.0.0.1 --port 8000 --reload
```

On Windows, you can also run `.\scripts\run_windows.ps1` after setup.

Open these local addresses in your browser:

- API documentation: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/health
- Loaded documents: http://127.0.0.1:8000/documents

Try a question in PowerShell:

```powershell
$body = @{ query = "What is a fraction?"; top_k = 3 } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/ask -ContentType "application/json" -Body $body
```

The default mode is **retrieval-only**. This API is a research and retrieval component for the VAJRA model; it does not load or run the VAJRA model by itself. It returns relevant passages and their source metadata. It does not pretend that a small text-search system is an LLM. If a local model server is configured, the retrieved passages can be passed to that model for a grounded draft answer.

## 4. Run the Qwen3-0.6B baseline (free cloud notebook)

1. Open [Kaggle Notebooks](https://www.kaggle.com/code) or [Google Colab](https://colab.research.google.com/).
2. Upload `notebooks/00_qwen3_0_6b_baseline.ipynb`.
3. On Kaggle, choose **Settings → Accelerator → GPU** if available and turn Internet on. On Colab, choose **Runtime → Change runtime type → T4 GPU** if available.
4. Run cells from top to bottom. The notebook also has a CPU fallback, but it may be slow.
5. It downloads `Qwen/Qwen3-0.6B` into the cloud session and runs a small set of Gujarati, Hindi and English prompts.
6. Download `qwen3_baseline_results.json` from the notebook output when finished.

The model card currently lists Qwen3-0.6B under Apache-2.0 and recommends a recent Transformers version (at least 4.51.0). Check the model card again before redistributing weights or using the model commercially: https://huggingface.co/Qwen/Qwen3-0.6B

**GPU access is not guaranteed.** Free notebook quotas and hardware availability can change. If a GPU is unavailable, keep working on the dataset, RAG, tests and evaluation harness; do not create multiple accounts to bypass quotas.

## 5. Dataset format

Each line in `data/samples/seed_examples.jsonl` is one JSON record. The full machine-readable schema is `data/schema/indic_record.schema.json`.

Required ideas:

- `language`: BCP-47-like code (`gu`, `hi`, `en`).
- `task_type`: the task (for example `qa`, `translation`, `explanation`).
- `input` and `target`: the prompt and reference target.
- `source.uri` and `source.license`: provenance and rights information.
- `quality.status`: `pending`, `reviewed` or `rejected`.
- `split`: `unassigned`, `train`, `validation` or `test`.

The supplied records are **original demonstration examples**, not an authoritative Indian-knowledge corpus. They are marked `pending` because they have not been independently reviewed. Do not train on them until a qualified reviewer verifies them and you assign a split.

Validate a JSONL file:

```powershell
python scripts\validate_dataset.py data\samples\seed_examples.jsonl
```

Require reviewer-approved records before a training export:

```powershell
python scripts\validate_dataset.py data\samples\seed_examples.jsonl --require-reviewed
```

The second command is expected to fail on the unreviewed demo data. That is intentional.

## 6. Add your own knowledge documents to RAG

Append one JSON object per line to `data/knowledge/documents.jsonl`:

```json
{"document_id":"your-doc-001","title":"Document title","language":"en","source_uri":"https://example.org/source","license":"CC-BY-4.0","text":"The exact text you have permission to use."}
```

Use a real source URL and its actual licence. `source_uri` may be a stable local identifier for original notes, but do not invent a government or academic source. Do not add personal/private data. Restart the API after editing the file; the documents are loaded at startup.

## 7. Optional local LLM connection

The starter does not download or run the VAJRA model on your computer. If you later have a model running on a machine you control through an OpenAI-compatible endpoint (for example, a local `llama.cpp` server), set these environment variables before starting the API:

```powershell
$env:VAJRA_LLM_BASE_URL = "http://127.0.0.1:8080/v1"
$env:VAJRA_LLM_MODEL = "local-model"
# Only set this if your local server requires a key:
# $env:VAJRA_LLM_API_KEY = "your-local-key"
uvicorn vajra.api.main:app --host 127.0.0.1 --port 8000 --reload
```

The server must implement `POST /chat/completions`. Keep it bound to localhost unless you understand network security. Do not expose an unauthenticated model server to the public internet. The application will fall back to retrieval-only mode if the model call fails and will report that fallback in the response.

## 8. Useful commands

```powershell
# Run tests
python -m pytest

# Validate the sample dataset
python scripts\validate_dataset.py data\samples\seed_examples.jsonl

# Run the API
uvicorn vajra.api.main:app --host 127.0.0.1 --port 8000 --reload
```

## 9. Repository map

```text
VAJRA-v0.1/
├── data/
│   ├── evaluation/baseline_prompts.json
│   ├── knowledge/documents.jsonl
│   ├── samples/seed_examples.jsonl
│   └── schema/indic_record.schema.json
├── docs/
├── notebooks/00_qwen3_0_6b_baseline.ipynb
├── scripts/validate_dataset.py
├── src/vajra/
│   ├── api/       # FastAPI endpoints
│   ├── dataset/   # JSONL validation
│   ├── model/     # optional local OpenAI-compatible client
│   └── rag/       # chunking and retrieval
└── tests/
```

## 10. What v0.1 does not do

- It does not train a new foundation model.
- It does not fine-tune Qwen3.
- It does not claim benchmark superiority.
- It does not include a paid or third-party API key.
- It does not make legal, medical or official-benefit decisions.
- It does not automatically verify factual correctness of user-added documents.

## 11. Next milestones

1. Collect 100–500 original or openly licensed examples, with provenance.
2. Have native speakers review Gujarati and Hindi examples.
3. Create an immutable held-out evaluation set before fine-tuning.
4. Run the Qwen3 baseline notebook and save the results.
5. Only then create a separate LoRA/QLoRA experiment on a free GPU, if allocated.
6. Publish limitations and actual measurements alongside every release.

## Citation and licence

See `CITATION.cff`, `LICENSE`, `docs/DATA_GOVERNANCE.md` and `docs/ARCHITECTURE.md`. Code and project-authored starter content are licensed under MIT unless a file or dataset record states otherwise. Third-party model weights and external datasets keep their own licences.
