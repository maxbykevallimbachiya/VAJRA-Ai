from __future__ import annotations

import os
from pathlib import Path
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_ROOT / ".env", override=False)

DATA_PATH = Path(os.getenv("VAJRA_KNOWLEDGE_PATH", str(PROJECT_ROOT / "data" / "knowledge" / "documents.jsonl")))
LLM_BASE_URL = os.getenv("VAJRA_LLM_BASE_URL", "").strip()
LLM_MODEL = os.getenv("VAJRA_LLM_MODEL", "local-model").strip()
LLM_API_KEY = os.getenv("VAJRA_LLM_API_KEY", "").strip()
LLM_TIMEOUT_SECONDS = float(os.getenv("VAJRA_LLM_TIMEOUT_SECONDS", "45"))
DEFAULT_TOP_K = int(os.getenv("VAJRA_TOP_K", "3"))
MIN_RELEVANCE = float(os.getenv("VAJRA_MIN_RELEVANCE", "0.01"))
