from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class KnowledgeDocument:
    document_id: str
    title: str
    language: str
    source_uri: str
    license: str
    text: str


@dataclass(frozen=True)
class RetrievedChunk:
    document_id: str
    title: str
    language: str
    source_uri: str
    license: str
    text: str
    score: float
