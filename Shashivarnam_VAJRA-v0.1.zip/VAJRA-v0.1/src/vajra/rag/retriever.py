from __future__ import annotations
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from vajra.rag.chunking import chunk_document
from vajra.rag.models import KnowledgeDocument, RetrievedChunk


class TfidfRetriever:
    """Lightweight character n-gram search; a baseline, not semantic embeddings."""
    def __init__(self, documents: list[KnowledgeDocument], chunk_size: int = 700, overlap: int = 100):
        self.chunks: list[RetrievedChunk] = []
        for document in documents:
            self.chunks.extend(chunk_document(document, chunk_size=chunk_size, overlap=overlap))
        self.vectorizer: TfidfVectorizer | None = None
        self.matrix = None
        if self.chunks:
            self.vectorizer = TfidfVectorizer(
                analyzer="char_wb",
                ngram_range=(2, 5),
                min_df=1,
                sublinear_tf=True,
                max_features=200_000,
                dtype=np.float32,
            )
            self.matrix = self.vectorizer.fit_transform([chunk.text for chunk in self.chunks])

    def search(self, query: str, top_k: int = 3, min_score: float = 0.01) -> list[RetrievedChunk]:
        if not query.strip():
            raise ValueError("query must not be empty")
        if top_k < 1 or top_k > 10:
            raise ValueError("top_k must be between 1 and 10")
        if self.vectorizer is None or self.matrix is None:
            return []
        query_vector = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vector, self.matrix).ravel()
        ranked = scores.argsort()[::-1]
        results: list[RetrievedChunk] = []
        for index in ranked:
            score = float(scores[index])
            if score < min_score:
                break
            source = self.chunks[int(index)]
            results.append(RetrievedChunk(
                document_id=source.document_id,
                title=source.title,
                language=source.language,
                source_uri=source.source_uri,
                license=source.license,
                text=source.text,
                score=score,
            ))
            if len(results) >= top_k:
                break
        return results
