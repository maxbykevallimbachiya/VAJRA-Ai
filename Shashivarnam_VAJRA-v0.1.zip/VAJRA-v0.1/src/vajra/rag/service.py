from __future__ import annotations
from vajra.model.local_client import LocalOpenAICompatibleClient, LocalModelError
from vajra.rag.models import KnowledgeDocument
from vajra.rag.retriever import TfidfRetriever


class RAGService:
    def __init__(self, documents: list[KnowledgeDocument], generator: LocalOpenAICompatibleClient | None = None, min_score: float = 0.01):
        self.documents = documents
        self.retriever = TfidfRetriever(documents)
        self.generator = generator
        self.min_score = min_score

    def list_documents(self) -> list[dict]:
        return [
            {"document_id": d.document_id, "title": d.title, "language": d.language,
             "source_uri": d.source_uri, "license": d.license}
            for d in self.documents
        ]

    def ask(self, query: str, top_k: int = 3) -> dict:
        hits = self.retriever.search(query, top_k=top_k, min_score=self.min_score)
        sources = [
            {"document_id": h.document_id, "title": h.title, "language": h.language,
             "source_uri": h.source_uri, "license": h.license, "score": round(h.score, 4),
             "excerpt": h.text}
            for h in hits
        ]
        if not hits:
            return {
                "query": query,
                "answer": "I could not find relevant material in the documents currently loaded. Add a reliable, permitted source or ask a narrower question.",
                "answer_mode": "no_evidence",
                "sources": [],
                "warning": "No relevant documents passed the retrieval threshold. This is not proof that the answer does not exist elsewhere.",
            }

        if self.generator is not None:
            try:
                answer = self.generator.generate_grounded(query, sources)
                return {"query": query, "answer": answer, "answer_mode": "local_model_grounded_draft", "sources": sources, "warning": "Generated text can still be wrong. Check the cited source passages."}
            except LocalModelError as exc:
                fallback_warning = str(exc)
            else:  # pragma: no cover
                fallback_warning = None
        else:
            fallback_warning = "No local model endpoint is configured; showing retrieved evidence rather than generated prose."

        evidence = "\n\n".join(f"[{hit.document_id}] {hit.title}: {hit.text}" for hit in hits)
        return {
            "query": query,
            "answer": "Relevant source passages:\n\n" + evidence,
            "answer_mode": "retrieval_only",
            "sources": sources,
            "warning": fallback_warning,
        }
