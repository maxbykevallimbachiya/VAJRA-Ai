from __future__ import annotations
import json
from pathlib import Path
from pydantic import BaseModel, ConfigDict, Field
from vajra.rag.models import KnowledgeDocument


class KnowledgeDocumentRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    document_id: str = Field(min_length=1)
    title: str = Field(min_length=1)
    language: str = Field(min_length=2)
    source_uri: str = Field(min_length=1)
    license: str = Field(min_length=2)
    text: str = Field(min_length=1)


def load_documents(path: str | Path) -> list[KnowledgeDocument]:
    file_path = Path(path)
    if not file_path.is_file():
        return []
    documents: list[KnowledgeDocument] = []
    seen: set[str] = set()
    with file_path.open("r", encoding="utf-8") as handle:
        for line_number, raw in enumerate(handle, start=1):
            if not raw.strip():
                continue
            try:
                record = KnowledgeDocumentRecord.model_validate_json(raw)
            except Exception as exc:
                raise ValueError(f"Invalid knowledge JSONL at {file_path}:{line_number}: {exc}") from exc
            if record.document_id in seen:
                raise ValueError(f"Duplicate document_id {record.document_id!r} at line {line_number}")
            seen.add(record.document_id)
            documents.append(KnowledgeDocument(**record.model_dump()))
    return documents
