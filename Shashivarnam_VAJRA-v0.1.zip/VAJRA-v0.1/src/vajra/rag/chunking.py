from __future__ import annotations
from vajra.rag.models import KnowledgeDocument, RetrievedChunk


def chunk_document(document: KnowledgeDocument, chunk_size: int = 700, overlap: int = 100) -> list[RetrievedChunk]:
    if chunk_size < 100:
        raise ValueError("chunk_size must be at least 100 characters")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be non-negative and smaller than chunk_size")

    text = " ".join(document.text.split())
    if not text:
        return []

    chunks: list[RetrievedChunk] = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text):
            # Prefer a natural whitespace boundary, but avoid tiny chunks.
            boundary = text.rfind(" ", start + int(chunk_size * 0.6), end)
            if boundary > start:
                end = boundary
        piece = text[start:end].strip()
        if piece:
            chunks.append(RetrievedChunk(
                document_id=document.document_id,
                title=document.title,
                language=document.language,
                source_uri=document.source_uri,
                license=document.license,
                text=piece,
                score=0.0,
            ))
        if end >= len(text):
            break
        start = max(start + 1, end - overlap)
    return chunks
