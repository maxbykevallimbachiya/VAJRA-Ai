from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, HttpUrl

SplitName = Literal["unassigned", "train", "validation", "test"]
QualityStatus = Literal["pending", "reviewed", "rejected"]


class SourceInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")
    uri: str = Field(min_length=1)
    title: str | None = None
    license: str = Field(min_length=2)
    source_type: Literal["original", "open_dataset", "human_written", "synthetic", "derived"]


class QualityInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: QualityStatus = "pending"
    reviewer: str | None = None
    score: float | None = Field(default=None, ge=0, le=1)
    review_notes: str | None = None


class IndicRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    example_id: str = Field(min_length=1, max_length=128)
    language: str = Field(pattern=r"^[a-z]{2,3}(-[A-Za-z0-9]{2,8})*$", max_length=16)
    script: str = Field(min_length=2, max_length=32)
    task_type: str = Field(min_length=2, max_length=64)
    input: str = Field(min_length=1)
    target: str = Field(min_length=1)
    source: SourceInfo
    is_synthetic: bool = False
    quality: QualityInfo = Field(default_factory=QualityInfo)
    split: SplitName = "unassigned"
    created_at: str | None = None
    notes: str | None = None
