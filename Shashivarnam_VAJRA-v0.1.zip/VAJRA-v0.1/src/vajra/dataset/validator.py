from __future__ import annotations

import json
from pathlib import Path
from pydantic import ValidationError
from vajra.dataset.schema import IndicRecord


class DatasetValidationError(ValueError):
    pass


def validate_jsonl(path: str | Path, require_reviewed: bool = False) -> dict:
    """Validate JSONL records and return a small audit summary."""
    file_path = Path(path)
    if not file_path.is_file():
        raise FileNotFoundError(f"Dataset file not found: {file_path}")

    seen: set[str] = set()
    counts: dict[str, int] = {}
    errors: list[str] = []
    total = 0

    with file_path.open("r", encoding="utf-8") as stream:
        for line_number, raw in enumerate(stream, start=1):
            if not raw.strip():
                continue
            total += 1
            try:
                record = IndicRecord.model_validate_json(raw)
            except ValidationError as exc:
                errors.append(f"Line {line_number}: {exc.errors(include_url=False)}")
                continue
            except Exception as exc:
                errors.append(f"Line {line_number}: invalid JSON: {exc}")
                continue

            if record.example_id in seen:
                errors.append(f"Line {line_number}: duplicate example_id {record.example_id!r}")
            seen.add(record.example_id)
            counts[record.language] = counts.get(record.language, 0) + 1

            if require_reviewed and record.quality.status != "reviewed":
                errors.append(
                    f"Line {line_number}: {record.example_id} is {record.quality.status!r}; reviewed records required"
                )
            if require_reviewed and not record.quality.reviewer:
                errors.append(f"Line {line_number}: {record.example_id} has no reviewer name")
            if record.source.license.strip().lower() in {"unknown", "tbd", ""}:
                errors.append(f"Line {line_number}: {record.example_id} has no usable source licence")

    summary = {"path": str(file_path), "records": total, "languages": counts, "errors": errors, "valid": not errors}
    if errors:
        raise DatasetValidationError(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary
