"""Shashivarnam research starter for the VAJRA Indian-language AI model."""
__version__ = "0.1.0"
