from __future__ import annotations
from fastapi import FastAPI, HTTPException
from vajra import __version__
from vajra.api.schemas import AskRequest, HealthResponse
from vajra.config import DATA_PATH, LLM_BASE_URL, LLM_MODEL, LLM_API_KEY, LLM_TIMEOUT_SECONDS, MIN_RELEVANCE
from vajra.model.local_client import LocalOpenAICompatibleClient
from vajra.rag.service import RAGService
from vajra.rag.store import load_documents


def create_app(data_path=DATA_PATH, min_score: float = MIN_RELEVANCE) -> FastAPI:
    documents = load_documents(data_path)
    generator = None
    if LLM_BASE_URL:
        generator = LocalOpenAICompatibleClient(
            base_url=LLM_BASE_URL,
            model=LLM_MODEL,
            api_key=LLM_API_KEY,
            timeout=LLM_TIMEOUT_SECONDS,
        )
    rag = RAGService(documents=documents, generator=generator, min_score=min_score)
    app = FastAPI(
        title="Shashivarnam Research API (VAJRA)",
        description="Shashivarnam research API supporting the VAJRA model programme. Low-resource Indic-language retrieval prototype; default mode does not require an LLM or load the VAJRA model.",
        version=__version__,
    )
    app.state.rag = rag

    @app.get("/health", response_model=HealthResponse)
    def health():
        return HealthResponse(
            status="ok",
            version=__version__,
            documents_loaded=len(documents),
            local_model_configured=generator is not None,
        )

    @app.get("/documents")
    def list_documents():
        return {"count": len(documents), "documents": rag.list_documents()}

    @app.post("/ask")
    def ask(request: AskRequest):
        try:
            return rag.ask(request.query, top_k=request.top_k)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    return app


app = create_app()
