from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    query: str = Field(min_length=2, max_length=2000)
    top_k: int = Field(default=3, ge=1, le=10)


class HealthResponse(BaseModel):
    status: str
    version: str
    documents_loaded: int
    local_model_configured: bool
