from __future__ import annotations
import json
import urllib.error
import urllib.request


class LocalModelError(RuntimeError):
    pass


class LocalOpenAICompatibleClient:
    """Calls a model server controlled by the user; no provider is preconfigured."""
    def __init__(self, base_url: str, model: str = "local-model", api_key: str = "", timeout: float = 45):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout

    def generate_grounded(self, question: str, contexts: list[dict]) -> str:
        endpoint = self.base_url if self.base_url.endswith("/chat/completions") else self.base_url + "/chat/completions"
        context_text = "\n\n".join(
            f"[Source: {item['document_id']} | {item['title']} | {item['source_uri']}]\n{item['text']}"
            for item in contexts
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "You are VAJRA, an evidence-grounded assistant. Answer using only the supplied context. "
                    "If the context does not contain the answer, say you do not have enough evidence. "
                    "Do not invent facts or sources. Add [document_id] citations for claims."
                ),
            },
            {"role": "user", "content": f"CONTEXT:\n{context_text}\n\nQUESTION:\n{question}"},
        ]
        payload = json.dumps({
            "model": self.model,
            "messages": messages,
            "temperature": 0.2,
            "max_tokens": 400,
        }).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        request = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                result = json.loads(response.read().decode("utf-8"))
            return str(result["choices"][0]["message"]["content"]).strip()
        except (urllib.error.URLError, TimeoutError, KeyError, IndexError, TypeError, ValueError) as exc:
            raise LocalModelError(f"Local model request failed: {exc}") from exc
