# Shashivarnam VAJRA model data governance

## Core rule

Publicly accessible does not automatically mean reusable for training or redistribution. Record the exact dataset/artifact, its licence, its source, and the permitted uses before downloading or including it.

## Required metadata

Every record must identify its language, task, source URI, licence, synthetic/original status, quality status and split. Unknown or missing rights are a reason to exclude the record from training.

## Review states

- `pending`: not yet checked by a qualified human; **not eligible for training export**.
- `reviewed`: a named human reviewer checked language, factual/content quality and source/rights metadata.
- `rejected`: known issue; retain only if needed for audit, never train on it.

The starter's demo examples are marked `pending` intentionally.

## Privacy

Do not collect personal information, private messages, account credentials, health data, children's identifiable information, or sensitive records. If a lawful, necessary dataset contains personal data, get appropriate expert review and apply minimisation, notice/consent and deletion controls before using it.

## Splits and leakage

Assign `train`, `validation`, and `test` only after deduplication. Keep related passages and near-duplicates in the same split. Keep the evaluation set private until final release where practical.

## Synthetic data

Record that data is synthetic, identify the teacher/tool and its applicable terms, and have a human review high-impact or Indic-language examples. Synthetic output can contain errors and may reproduce memorised material; do not treat it as verified ground truth.

## Licensing

Use a licence that actually covers the intended use. Do not assume a dataset licence grants rights to underlying third-party content. Check the individual model and dataset cards before commercial use, redistribution or training.
