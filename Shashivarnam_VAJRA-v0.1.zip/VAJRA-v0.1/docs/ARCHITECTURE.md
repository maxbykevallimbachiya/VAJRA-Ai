# Shashivarnam VAJRA v0.1 architecture

```text
Browser / curl
     |
     v
FastAPI (localhost)
     |
     +--> Request validation (Pydantic)
     |
     +--> RAG service
     |       |
     |       +--> JSONL knowledge documents
     |       +--> Character n-gram TF-IDF index
     |       +--> Chunk metadata and source provenance
     |
     +--> Optional local OpenAI-compatible chat endpoint
             |
             +--> Only receives retrieved context + user question
```

## Design choices

- **No local foundation model by default:** protects the 12 GB RAM machine from large downloads and avoids turning setup into a hardware problem.
- **Character n-gram retrieval:** a lightweight CPU baseline that can match across scripts without a separate embedding model. It is a research baseline, not state-of-the-art semantic search.
- **Explicit retrieval-only fallback:** if no local model is configured, the Shashivarnam research API returns passages and citations, not invented generated prose.
- **Source metadata:** every knowledge record carries a source URI and licence label. These values must be accurate and reviewed by the contributor.
- **Small service surface:** only read/query endpoints and a local health endpoint are enabled initially.

## Future architecture (not implemented in v0.1)

- Hybrid BM25 + multilingual embedding retrieval.
- Human-reviewed query and answer evaluation.
- A separate model inference service.
- Model adapters trained on approved data.
- Speech recognition and text-to-speech.
- User-approved memory with export/deletion controls.
- Authenticated multi-user deployment.

Do not add agents or arbitrary shell execution to the first release.
