# Shashivarnam roadmap for the VAJRA model

## v0.1 — starter (this repository)
- Local retrieval API.
- Dataset schema and validator.
- Qwen3-0.6B cloud baseline notebook.
- Tests and documentation.

## v0.2 — measurement and review
- 100–500 human-reviewed test prompts across Gujarati, Hindi and English.
- Native-speaker quality review.
- Baseline result tracking and a fixed evaluation split.
- Better hybrid retrieval if evaluation shows it is needed.

## v0.3 — small training experiment
- Only after data rights and reviews are complete.
- Small LoRA/QLoRA adapter on an allocated GPU.
- Compare base and adapted model on held-out prompts.
- Record compute, memory, versions, hyperparameters and failures.

## v1.0 — product pilot
- Authenticated user-facing product if deployed beyond localhost.
- Privacy controls, abuse monitoring and independent evaluation.
- Education pilot with educator-reviewed content.

## Explicit non-goals for v0.1
- Pretraining a foundation model.
- Building AGI.
- Deploying an autonomous agent with unrestricted computer access.
- Claiming that a small model beats frontier systems.
