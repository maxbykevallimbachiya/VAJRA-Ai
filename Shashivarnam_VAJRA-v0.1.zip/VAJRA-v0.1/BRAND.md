# Shashivarnam and VAJRA brand identity

- **Company / initiative name:** Shashivarnam
- **Flagship AI model:** VAJRA
- **First planned product:** VAJRA EDU, an education product powered by the VAJRA model
- **Research languages:** Gujarati, Hindi and English initially

Use the names consistently: Shashivarnam is the organisation developing the model; VAJRA is the model. The v0.1 repository contains a retrieval API, dataset schema, validator, tests and a Qwen3 baseline notebook. It does not contain a newly trained VAJRA foundation model.

The name is the founder-selected brand. This file does not assert that a company has been legally incorporated or that the name/trademark has been cleared. Verify legal entity name, company registration, domain and trademark availability before formal commercial use.
