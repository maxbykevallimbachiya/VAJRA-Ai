from vajra.rag.chunking import chunk_document
from vajra.rag.models import KnowledgeDocument


def test_chunk_document_keeps_source_metadata():
    doc = KnowledgeDocument("d1", "Demo", "en", "local://d1", "MIT", "word " * 300)
    chunks = chunk_document(doc, chunk_size=300, overlap=40)
    assert len(chunks) > 1
    assert all(chunk.document_id == "d1" for chunk in chunks)
    assert all(chunk.source_uri == "local://d1" for chunk in chunks)


def test_empty_document_has_no_chunks():
    doc = KnowledgeDocument("d2", "Empty", "en", "local://d2", "MIT", "   ")
    assert chunk_document(doc) == []
