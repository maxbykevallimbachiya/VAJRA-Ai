from vajra.rag.models import KnowledgeDocument
from vajra.rag.retriever import TfidfRetriever


def test_retriever_finds_relevant_document():
    docs = [
        KnowledgeDocument("math", "Fractions", "en", "local://math", "MIT", "A fraction represents part of a whole. The numerator is above the fraction bar."),
        KnowledgeDocument("plants", "Plants", "en", "local://plants", "MIT", "Plants use sunlight, water and carbon dioxide for photosynthesis."),
    ]
    results = TfidfRetriever(docs).search("What does a fraction represent?", top_k=2, min_score=0.01)
    assert results
    assert results[0].document_id == "math"


def test_empty_index_returns_no_results():
    assert TfidfRetriever([]).search("question") == []
