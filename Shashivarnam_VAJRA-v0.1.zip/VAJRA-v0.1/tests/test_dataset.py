import json
from pathlib import Path
import pytest
from vajra.dataset.validator import validate_jsonl, DatasetValidationError


def test_seed_dataset_is_valid_but_pending():
    root = Path(__file__).resolve().parents[1]
    summary = validate_jsonl(root / "data" / "samples" / "seed_examples.jsonl")
    assert summary["valid"] is True
    assert summary["records"] >= 3
    with pytest.raises(DatasetValidationError):
        validate_jsonl(root / "data" / "samples" / "seed_examples.jsonl", require_reviewed=True)


def test_duplicate_ids_are_rejected(tmp_path):
    item = {
        "example_id": "same", "language": "en", "script": "Latin", "task_type": "qa",
        "input": "Question?", "target": "Answer.",
        "source": {"uri": "local://test", "license": "MIT", "source_type": "original"},
        "is_synthetic": False, "quality": {"status": "pending"}, "split": "unassigned"
    }
    file_path = tmp_path / "duplicate.jsonl"
    file_path.write_text(json.dumps(item) + "\n" + json.dumps(item) + "\n", encoding="utf-8")
    with pytest.raises(DatasetValidationError):
        validate_jsonl(file_path)
