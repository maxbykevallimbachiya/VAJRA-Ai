from pathlib import Path
from fastapi.testclient import TestClient
from vajra.api.main import create_app


def test_health_and_ask_routes():
    root = Path(__file__).resolve().parents[1]
    app = create_app(root / "data" / "knowledge" / "documents.jsonl", min_score=0.0)
    client = TestClient(app)

    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"

    response = client.post("/ask", json={"query": "What is a fraction?", "top_k": 2})
    assert response.status_code == 200
    body = response.json()
    assert body["answer_mode"] == "retrieval_only"
    assert body["sources"]


def test_empty_question_is_rejected():
    root = Path(__file__).resolve().parents[1]
    client = TestClient(create_app(root / "data" / "knowledge" / "documents.jsonl"))
    response = client.post("/ask", json={"query": "", "top_k": 3})
    assert response.status_code == 422
